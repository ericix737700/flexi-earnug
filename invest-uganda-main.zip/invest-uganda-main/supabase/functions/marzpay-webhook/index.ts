import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const payload = await req.json();
    console.log("MarzPay webhook received:", JSON.stringify(payload));

    const adminClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const eventType = payload.event_type;
    const transaction = payload.transaction;

    if (!transaction) {
      return new Response(JSON.stringify({ error: "Invalid payload" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const reference = transaction.reference;
    const status = transaction.status;

    // Handle collection events (deposits)
    if (eventType?.startsWith("collection.")) {
      if (status === "completed") {
        // Find the deposit by reference (which is the deposit ID)
        const { data: deposit } = await adminClient
          .from("deposits")
          .select("*")
          .eq("id", reference)
          .single();

        if (deposit && deposit.status === "pending") {
          // Get user's current balance
          const { data: profile } = await adminClient
            .from("profiles")
            .select("balance")
            .eq("user_id", deposit.user_id)
            .single();

          if (profile) {
            const newBalance = Number(profile.balance) + Number(deposit.amount);

            // Credit user balance
            await adminClient
              .from("profiles")
              .update({ balance: newBalance })
              .eq("user_id", deposit.user_id);

            // Create transaction record
            await adminClient.from("transactions").insert({
              user_id: deposit.user_id,
              transaction_type: "earning",
              amount: deposit.amount,
              balance_after: newBalance,
              description: `Deposit via MarzPay - Ref: ${transaction.uuid || reference}`,
            });

            // Update deposit as approved
            await adminClient
              .from("deposits")
              .update({
                status: "approved",
                processed_at: new Date().toISOString(),
              })
              .eq("id", deposit.id);

            // Notify user
            await adminClient.from("notifications").insert({
              user_id: deposit.user_id,
              title: "Deposit Successful",
              message: `Your deposit of UGX ${Number(deposit.amount).toLocaleString()} has been received and credited.`,
              notification_type: "transaction",
            });
          }
        }
      } else if (status === "failed" || status === "cancelled") {
        await adminClient
          .from("deposits")
          .update({
            status: "rejected",
            rejection_reason: `Payment ${status} by provider`,
            processed_at: new Date().toISOString(),
          })
          .eq("id", reference);

        const { data: deposit } = await adminClient
          .from("deposits")
          .select("user_id, amount")
          .eq("id", reference)
          .single();

        if (deposit) {
          await adminClient.from("notifications").insert({
            user_id: deposit.user_id,
            title: "Deposit Failed",
            message: `Your deposit of UGX ${Number(deposit.amount).toLocaleString()} ${status}. Please try again.`,
            notification_type: "transaction",
          });
        }
      }
    }

    // Handle disbursement events (withdrawals)
    if (eventType?.startsWith("disbursement.")) {
      if (status === "completed") {
        await adminClient
          .from("withdrawals")
          .update({
            status: "processed",
            processed_at: new Date().toISOString(),
          })
          .eq("id", reference);

        const { data: withdrawal } = await adminClient
          .from("withdrawals")
          .select("user_id, amount")
          .eq("id", reference)
          .single();

        if (withdrawal) {
          await adminClient.from("notifications").insert({
            user_id: withdrawal.user_id,
            title: "Withdrawal Successful",
            message: `Your withdrawal of UGX ${Number(withdrawal.amount).toLocaleString()} has been sent to your mobile money account.`,
            notification_type: "transaction",
          });
        }
      } else if (status === "failed" || status === "cancelled") {
        // Refund balance on failed withdrawal
        const { data: withdrawal } = await adminClient
          .from("withdrawals")
          .select("*")
          .eq("id", reference)
          .single();

        if (withdrawal && withdrawal.status !== "rejected") {
          const { data: profile } = await adminClient
            .from("profiles")
            .select("balance")
            .eq("user_id", withdrawal.user_id)
            .single();

          if (profile) {
            const newBalance = Number(profile.balance) + Number(withdrawal.amount);

            await adminClient
              .from("profiles")
              .update({ balance: newBalance })
              .eq("user_id", withdrawal.user_id);

            await adminClient.from("transactions").insert({
              user_id: withdrawal.user_id,
              transaction_type: "adjustment",
              amount: withdrawal.amount,
              balance_after: newBalance,
              description: `Withdrawal refund - payment ${status}`,
            });
          }

          await adminClient
            .from("withdrawals")
            .update({
              status: "rejected",
              rejection_reason: `Payment ${status} by provider`,
              processed_at: new Date().toISOString(),
            })
            .eq("id", reference);

          await adminClient.from("notifications").insert({
            user_id: withdrawal.user_id,
            title: "Withdrawal Failed",
            message: `Your withdrawal of UGX ${Number(withdrawal.amount).toLocaleString()} failed. The amount has been refunded to your account.`,
            notification_type: "transaction",
          });
        }
      }
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Webhook error:", error);
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
