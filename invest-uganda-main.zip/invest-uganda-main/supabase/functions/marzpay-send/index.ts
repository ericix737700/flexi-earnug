import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminUserId = user.id;

    // Verify admin role
    const adminClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: roleData } = await adminClient
      .from("user_roles")
      .select("role")
      .eq("user_id", adminUserId)
      .eq("role", "admin")
      .single();

    if (!roleData) {
      return new Response(JSON.stringify({ error: "Admin access required" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { withdrawal_id, amount, phone_number } = await req.json();

    if (!withdrawal_id || !amount || !phone_number) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const marzpayUsername = Deno.env.get("MARZPAY_USERNAME");
    const marzpayPassword = Deno.env.get("MARZPAY_PASSWORD");
    if (!marzpayUsername || !marzpayPassword) {
      return new Response(
        JSON.stringify({ error: "Payment gateway not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    const marzpayAuth = btoa(`${marzpayUsername}:${marzpayPassword}`);

    // Format phone number
    let formattedPhone = phone_number.trim();
    if (formattedPhone.startsWith("0")) {
      formattedPhone = "+256" + formattedPhone.substring(1);
    } else if (!formattedPhone.startsWith("+")) {
      formattedPhone = "+256" + formattedPhone;
    }

    const reference = withdrawal_id;
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const callbackUrl = `${supabaseUrl}/functions/v1/marzpay-webhook`;

    const formData = new FormData();
    formData.append("phone_number", formattedPhone);
    formData.append("amount", String(amount));
    formData.append("country", "UG");
    formData.append("reference", reference);
    formData.append("description", "FlexiEarn withdrawal payout");
    formData.append("callback_url", callbackUrl);

    const response = await fetch("https://wallet.wearemarz.com/api/v1/send-money", {
      method: "POST",
      headers: {
        Authorization: `Basic ${marzpayAuth}`,
      },
      body: formData,
    });

    const result = await response.json();

    if (result.status === "success") {
      // Update withdrawal status to processing
      await adminClient
        .from("withdrawals")
        .update({
          status: "approved",
          processed_by: adminUserId,
          processed_at: new Date().toISOString(),
        })
        .eq("id", withdrawal_id);

      return new Response(JSON.stringify({ success: true, data: result.data }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } else {
      return new Response(
        JSON.stringify({ error: result.message || "Send money failed" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  } catch (error) {
    console.error("MarzPay send error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
