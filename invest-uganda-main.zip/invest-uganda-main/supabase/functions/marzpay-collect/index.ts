import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = user.id;
    const { amount, phone_number, deposit_id } = await req.json();

    if (!amount || !phone_number || !deposit_id) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: amount, phone_number, deposit_id" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Format phone number to +256 format
    let formattedPhone = phone_number.trim();
    if (formattedPhone.startsWith("0")) {
      formattedPhone = "+256" + formattedPhone.substring(1);
    } else if (!formattedPhone.startsWith("+")) {
      formattedPhone = "+256" + formattedPhone;
    }

    const marzpayUsername = Deno.env.get("MARZPAY_USERNAME");
    const marzpayPassword = Deno.env.get("MARZPAY_PASSWORD");
    if (!marzpayUsername || !marzpayPassword) {
      return new Response(
        JSON.stringify({ error: "Payment gateway not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    const marzpayAuth = btoa(`${marzpayUsername}:${marzpayPassword}`);

    // Use deposit_id as UUID reference
    const reference = deposit_id;

    // Build callback URL
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const callbackUrl = `${supabaseUrl}/functions/v1/marzpay-webhook`;

    // Create form data for MarzPay
    const formData = new FormData();
    formData.append("phone_number", formattedPhone);
    formData.append("amount", String(amount));
    formData.append("country", "UG");
    formData.append("reference", reference);
    formData.append("description", "Deposit to FlexiEarn wallet");
    formData.append("callback_url", callbackUrl);

    const response = await fetch("https://wallet.wearemarz.com/api/v1/collect-money", {
      method: "POST",
      headers: {
        Authorization: `Basic ${marzpayAuth}`,
      },
      body: formData,
    });

    const result = await response.json();

    if (result.status === "success") {
      // Update deposit with MarzPay reference
      const adminClient = createClient(
        Deno.env.get("SUPABASE_URL")!,
        Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
      );

      await adminClient
        .from("deposits")
        .update({
          transaction_id: result.data?.transaction?.uuid || reference,
          status: "pending",
        })
        .eq("id", deposit_id)
        .eq("user_id", userId);

      return new Response(JSON.stringify({ success: true, data: result.data }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } else {
      return new Response(
        JSON.stringify({ error: result.message || "Collection failed" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  } catch (error) {
    console.error("MarzPay collect error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
