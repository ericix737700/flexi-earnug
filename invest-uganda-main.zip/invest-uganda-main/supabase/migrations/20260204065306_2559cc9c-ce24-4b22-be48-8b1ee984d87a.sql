-- Create deposit status enum
CREATE TYPE public.deposit_status AS ENUM ('pending', 'approved', 'rejected');

-- Create deposits table
CREATE TABLE public.deposits (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    amount NUMERIC NOT NULL,
    transaction_id TEXT NOT NULL,
    status deposit_status NOT NULL DEFAULT 'pending',
    rejection_reason TEXT,
    processed_at TIMESTAMP WITH TIME ZONE,
    processed_by UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.deposits ENABLE ROW LEVEL SECURITY;

-- Users can insert own deposits
CREATE POLICY "Users can insert own deposits"
ON public.deposits
FOR INSERT
WITH CHECK (user_id = auth.uid());

-- Users can view own deposits
CREATE POLICY "Users can view own deposits"
ON public.deposits
FOR SELECT
USING (user_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

-- Admins can update deposits
CREATE POLICY "Admins can update deposits"
ON public.deposits
FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));