-- Create storage bucket for task videos
INSERT INTO storage.buckets (id, name, public)
VALUES ('task-videos', 'task-videos', true);

-- Allow anyone to view videos (public bucket)
CREATE POLICY "Anyone can view task videos"
ON storage.objects FOR SELECT
USING (bucket_id = 'task-videos');

-- Only admins can upload videos
CREATE POLICY "Admins can upload task videos"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'task-videos' 
  AND public.has_role(auth.uid(), 'admin'::app_role)
);

-- Only admins can update videos
CREATE POLICY "Admins can update task videos"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'task-videos' 
  AND public.has_role(auth.uid(), 'admin'::app_role)
);

-- Only admins can delete videos
CREATE POLICY "Admins can delete task videos"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'task-videos' 
  AND public.has_role(auth.uid(), 'admin'::app_role)
);