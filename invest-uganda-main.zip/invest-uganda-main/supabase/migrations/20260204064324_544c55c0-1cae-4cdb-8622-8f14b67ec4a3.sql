-- Insert default merchant settings
INSERT INTO public.platform_settings (setting_key, setting_value, description)
VALUES 
  ('merchant_name', 'FlexiEarn Payments', 'Name of the merchant for deposits'),
  ('merchant_id', '256700000000', 'Merchant Mobile Money number/ID for deposits')
ON CONFLICT (setting_key) DO NOTHING;