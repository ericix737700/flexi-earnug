import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Trash2, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

export interface TriviaQuestion {
  question: string;
  answers: [string, string, string, string];
  correctIndex: number;
}

interface TriviaQuestionEditorProps {
  questions: TriviaQuestion[];
  onChange: (questions: TriviaQuestion[]) => void;
}

export function TriviaQuestionEditor({ questions, onChange }: TriviaQuestionEditorProps) {
  const addQuestion = () => {
    onChange([
      ...questions,
      { question: "", answers: ["", "", "", ""], correctIndex: 0 },
    ]);
  };

  const removeQuestion = (index: number) => {
    onChange(questions.filter((_, i) => i !== index));
  };

  const updateQuestion = (index: number, field: string, value: string) => {
    const updated = [...questions];
    updated[index] = { ...updated[index], [field]: value };
    onChange(updated);
  };

  const updateAnswer = (qIndex: number, aIndex: number, value: string) => {
    const updated = [...questions];
    const answers = [...updated[qIndex].answers] as [string, string, string, string];
    answers[aIndex] = value;
    updated[qIndex] = { ...updated[qIndex], answers };
    onChange(updated);
  };

  const setCorrectAnswer = (qIndex: number, aIndex: number) => {
    const updated = [...questions];
    updated[qIndex] = { ...updated[qIndex], correctIndex: aIndex };
    onChange(updated);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">
          Trivia Questions ({questions.length})
        </Label>
        <Button type="button" variant="outline" size="sm" onClick={addQuestion}>
          <Plus className="mr-1 h-3 w-3" />
          Add Question
        </Button>
      </div>

      {questions.length === 0 && (
        <p className="text-sm text-muted-foreground text-center py-4">
          No questions added yet. Click "Add Question" to start.
        </p>
      )}

      {questions.map((q, qIndex) => (
        <Card key={qIndex} className="border-dashed">
          <CardContent className="space-y-3 pt-4">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 space-y-2">
                <Label className="text-xs text-muted-foreground">
                  Question {qIndex + 1}
                </Label>
                <Input
                  placeholder="Enter your question..."
                  value={q.question}
                  onChange={(e) => updateQuestion(qIndex, "question", e.target.value)}
                />
              </div>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="text-destructive mt-5"
                onClick={() => removeQuestion(qIndex)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>

            <Label className="text-xs text-muted-foreground">
              Answers (click to mark correct)
            </Label>
            <div className="grid grid-cols-1 gap-2">
              {q.answers.map((answer, aIndex) => (
                <div
                  key={aIndex}
                  className={cn(
                    "flex items-center gap-2 rounded-md border p-2 cursor-pointer transition-colors",
                    q.correctIndex === aIndex
                      ? "border-green-500 bg-green-50 dark:bg-green-950/30"
                      : "hover:bg-muted/50"
                  )}
                  onClick={() => setCorrectAnswer(qIndex, aIndex)}
                >
                  <CheckCircle2
                    className={cn(
                      "h-5 w-5 shrink-0",
                      q.correctIndex === aIndex
                        ? "text-green-500"
                        : "text-muted-foreground/30"
                    )}
                  />
                  <Input
                    placeholder={`Answer ${aIndex + 1}`}
                    value={answer}
                    onChange={(e) => updateAnswer(qIndex, aIndex, e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                    className="border-0 p-0 h-auto focus-visible:ring-0 bg-transparent"
                  />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
