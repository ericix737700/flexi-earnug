import { usePlatformSettings } from "@/hooks/usePlatformSettings";

export function usePlatformLogo() {
  const { data: settings } = usePlatformSettings();
  const logoUrl = settings?.platform_logo || "";
  return logoUrl;
}
