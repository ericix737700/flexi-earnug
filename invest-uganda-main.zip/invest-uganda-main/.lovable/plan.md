

# FlexiEarn Uganda - Task-Based Earning Platform

A mobile-friendly platform where Ugandan users earn money by completing simple tasks, with full admin control.

---

## 🎯 Platform Overview

**User App**: Clean, mobile-first interface where users register, complete tasks, earn rewards, and withdraw via Mobile Money (MTN/Airtel).

**Admin Panel**: Complete control center to manage users, tasks, payments, and platform settings.

---

## 📱 User App Features

### 1. Authentication & Registration
- Phone number verification (OTP via SMS)
- One-time registration fee payment (5,000 UGX default, admin-configurable)
- Simple profile setup (name, phone, referral code if any)

### 2. Home Dashboard
- Current balance display in UGX
- Quick access to available tasks
- Daily check-in button with streak counter
- Earnings summary (today, this week, total)

### 3. Task Center
- **Watch Videos/Ads** - View promotional content, earn per video
- **Complete Surveys** - Answer questions, earn per survey
- **Trivia Questions** - Fun quiz challenges with rewards
- **Daily Check-ins** - Log in daily for bonus earnings
- Each task shows reward amount and estimated time

### 4. Referral Program
- Unique referral code for each user
- Share link via WhatsApp, SMS, social media
- One-time bonus when referral successfully registers and pays
- Referral tracking (who joined, pending, completed)

### 5. Wallet & Withdrawals
- Real-time balance display
- Instant withdrawal to MTN or Airtel Mobile Money
- Transaction history (earnings + withdrawals)
- Integration with your provided payment API

### 6. Profile & Settings
- Edit profile details
- View account status
- Support/Help section
- Logout

---

## 🔐 Admin Panel Features

### 1. Dashboard & Analytics
- Total registered users
- Active users (daily/weekly)
- Total earnings distributed
- Revenue from registration fees
- Pending withdrawals count
- Charts for user growth & earnings trends

### 2. User Management
- View all users with search/filter
- User details: profile, balance, task history, referrals
- Actions: Suspend, Block, Delete accounts
- **Top up or deduct user balance** (with reason logging)
- View user's complete activity log

### 3. Task Management
- Create new tasks (video, survey, trivia, etc.)
- Set task title, description, and reward amount
- Upload videos or create quiz questions
- Enable/disable tasks
- Set task availability (active dates, daily limits)
- View task completion statistics

### 4. Withdrawal Management
- View all withdrawal requests
- Approve or reject with reason
- Mark as processed after payment
- Bulk actions for efficiency
- Payment status tracking

### 5. Platform Settings
- Set/update registration fee amount
- Configure referral bonus amount
- Set minimum withdrawal amount
- Configure task reward ranges
- Platform announcement/notice for users

### 6. Financial Reports
- Daily/weekly/monthly revenue reports
- User earnings reports
- Withdrawal reports
- Export to CSV/Excel

---

## 💳 Payment Integration

Will integrate with your Mobile Money API provider for:
- Receiving registration fee payments
- Processing user withdrawals to MTN/Airtel

---

## 🛠 Technical Approach

- **Frontend**: Modern, mobile-responsive React app
- **Backend**: Supabase (database, authentication, edge functions)
- **Payments**: Your provided Mobile Money API
- **Security**: Phone OTP verification, secure admin authentication, proper role-based access

---

## 📋 What I'll Need From You

1. **Mobile Money API documentation** from your provider
3. **Logo and brand colors** (optional - can use defaults)

